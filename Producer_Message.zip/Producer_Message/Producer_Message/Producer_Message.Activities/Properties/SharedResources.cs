﻿
namespace UiPath.Shared.Localization
{
    class SharedResources : Producer_Message.Activities.Properties.Resources
    {
    }
}