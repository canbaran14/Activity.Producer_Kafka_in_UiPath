using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using Producer_Message.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using System.Dynamic;
using System.Collections.Concurrent;
using Confluent.Kafka;
using Newtonsoft.Json;

namespace Producer_Message.Activities
{
    [LocalizedDisplayName(nameof(Resources.Produce_Message_DisplayName))]
    [LocalizedDescription(nameof(Resources.Produce_Message_Description))]
    public class Produce_Message : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.Timeout_DisplayName))]
        [LocalizedDescription(nameof(Resources.Timeout_Description))]
        public InArgument<int> TimeoutMS { get; set; } = 60000;

        [LocalizedDisplayName(nameof(Resources.Produce_Message_LingerSize_DisplayName))]
        [LocalizedDescription(nameof(Resources.Produce_Message_LingerSize_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<int> LingerSize { get; set; }

        [LocalizedDisplayName(nameof(Resources.Produce_Message_KafkaRequestTimeOut_DisplayName))]
        [LocalizedDescription(nameof(Resources.Produce_Message_KafkaRequestTimeOut_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<int> KafkaRequestTimeOut { get; set; } = 30000;

        [LocalizedDisplayName(nameof(Resources.Produce_Message_BatchSize_DisplayName))]
        [LocalizedDescription(nameof(Resources.Produce_Message_BatchSize_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<int> BatchSize { get; set; } = 1000000;

        [LocalizedDisplayName(nameof(Resources.Produce_Message_Message_DisplayName))]
        [LocalizedDescription(nameof(Resources.Produce_Message_Message_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<Dictionary<string, object>> Message { get; set; }

        [LocalizedDisplayName(nameof(Resources.Produce_Message_Topic_DisplayName))]
        [LocalizedDescription(nameof(Resources.Produce_Message_Topic_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Topic { get; set; }

        [LocalizedDisplayName(nameof(Resources.Produce_Message_Server_DisplayName))]
        [LocalizedDescription(nameof(Resources.Produce_Message_Server_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Server { get; set; }

        [LocalizedDisplayName(nameof(Resources.Produce_Message_Key_DisplayName))]
        [LocalizedDescription(nameof(Resources.Produce_Message_Key_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Key { get; set; }

        [LocalizedDisplayName(nameof(Resources.Produce_Message_Result_DisplayName))]
        [LocalizedDescription(nameof(Resources.Produce_Message_Result_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public OutArgument<Int32> Result { get; set; }

        #endregion


        #region Constructors

        public Produce_Message()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (Message == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(Message)));
            if (Server == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(Server)));
            if (Topic == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(Topic)));

            base.CacheMetadata(metadata);
        }

        private static ConcurrentDictionary<string, IProducer<string, string>> kafka_servers = new ConcurrentDictionary<string, IProducer<string, string>>();

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var timeout = TimeoutMS.Get(context);
            var message = Message.Get(context);
            var key = Key.Get(context);
            var servers = Server.Get(context);
            var topic = Topic.Get(context);
            var batch_size = BatchSize.Get(context);
            var kafka_reqeust_timeout = KafkaRequestTimeOut.Get(context);
            var linger_size = LingerSize.Get(context);

            // Set a timeout on the execution
            var task = ExecuteWithTimeout(context, cancellationToken);
            if (await Task.WhenAny(task, Task.Delay(timeout, cancellationToken)) != task) throw new TimeoutException(Resources.Timeout_Error);


            var producer = kafka_servers.GetOrAdd(servers, _ =>
            {
                var config = new ProducerConfig { BootstrapServers = servers, CompressionType = CompressionType.Lz4, Acks = Acks.All, LingerMs = linger_size, RequestTimeoutMs = kafka_reqeust_timeout, BatchSize = batch_size };
                IProducer<string, string> p = new ProducerBuilder<string, string>(config).Build();
                return p;
            });

            var expando = new ExpandoObject() as IDictionary<string, Object>;
            foreach (var kvp in message)
                expando.Add(kvp.Key, kvp.Value);
            string serializedEmployee = JsonConvert.SerializeObject(message);

            var dr = await producer.ProduceAsync(topic, new Message<string, string>()
            { Key = key, Value = serializedEmployee });
            Console.WriteLine($"Delivered '{dr.Value}' to '{dr.TopicPartitionOffset}'");

            // Outputs
            return (ctx) => {
                Result.Set(ctx, 1);
            };
        }

        private async Task ExecuteWithTimeout(AsyncCodeActivityContext context, CancellationToken cancellationToken = default)
        {
            throw new TimeoutException("Timeout reached. Please check your servers and topic information.");
        }

        #endregion
    }
}

