using System.Activities.Presentation.Metadata;
using System.ComponentModel;
using System.ComponentModel.Design;
using Producer_Message.Activities.Design.Designers;
using Producer_Message.Activities.Design.Properties;

namespace Producer_Message.Activities.Design
{
    public class DesignerMetadata : IRegisterMetadata
    {
        public void Register()
        {
            var builder = new AttributeTableBuilder();
            builder.ValidateTable();

            var categoryAttribute = new CategoryAttribute($"{Resources.Category}");

            builder.AddCustomAttributes(typeof(Produce_Message), categoryAttribute);
            builder.AddCustomAttributes(typeof(Produce_Message), new DesignerAttribute(typeof(Produce_MessageDesigner)));
            builder.AddCustomAttributes(typeof(Produce_Message), new HelpKeywordAttribute(""));


            MetadataStore.AddAttributeTable(builder.CreateTable());
        }
    }
}
