namespace Producer_Message.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for Produce_MessageDesigner.xaml
    /// </summary>
    public partial class Produce_MessageDesigner
    {
        public Produce_MessageDesigner()
        {
            InitializeComponent();
        }
    }
}
