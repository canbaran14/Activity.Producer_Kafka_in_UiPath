﻿
namespace UiPath.Shared.Localization
{
    class SharedResources : Producer_Message.Properties.Resources
    {
    }
}